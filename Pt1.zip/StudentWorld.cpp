#include "StudentWorld.h"
#include <string>
using namespace std;

GameWorld* createStudentWorld(string assetDir)
{
	return new StudentWorld(assetDir);
}

//bool StudentWorld::overlap(int xCoord, int yCoord) //check this to see if map properly
//{
//	for (int x = 0; x < SPRITE_WIDTH; x++)
//	{
//		for (int y = 0; y < SPRITE_HEIGHT; y++)
//		{
//			Dirt* d = dirtGrid[xCoord + x][yCoord + y];
//			if (d != nullptr)
//				if (d->getX() == x + xCoord && d->getY() == y + yCoord)
//					return true;
//		}
//	}
//	/*for (int c = 0; c < SPRITE_WIDTH; c++)
//	{
//		for (int r = 0; r < SPRITE_HEIGHT; r++)
//		{
//			
//			Dirt* d = dirtGrid[y - r][x - c];
//			if (d != nullptr)
//				if (d->getX() == x + c && d->getY() == y + r)
//					return true;
//		}
//	}*/
//	return false;
//}
void StudentWorld::removeDirt(int xCoord, int yCoord) // removes dirt objects overlapping player
{
	for (int x = 0; x < SPRITE_WIDTH; x++)
	{
		for (int y = 0; y < SPRITE_HEIGHT; y++)
		{
			Dirt* d = dirtGrid[xCoord + x][yCoord + y];
			if (d != nullptr)
			{
				delete d;
				dirtGrid[xCoord + x][yCoord + y] = nullptr;
				playSound(SOUND_DIG);
			}
		}
	}
}
StudentWorld::~StudentWorld()
{
	delete frackman;
	for (int r = 0; r < VIEW_HEIGHT; r++)
	{
		for (int c = 0; c < VIEW_WIDTH; c++)
		{
			Dirt* d = dirtGrid[r][c];
			delete d;
		}
	}
}
void StudentWorld::gridNull()
{
	for (int r = 0; r < VIEW_HEIGHT; r++)
	{
		for (int c = 0; c < VIEW_WIDTH; c++)
		{
			dirtGrid[r][c] = nullptr;
		}
	}
}
void StudentWorld::setUpGrid()
{
	gridNull();

	for (int x = 0; x < VIEW_WIDTH; x++)
	{
		for (int y = 0; y < VIEW_HEIGHT; y++)
		{
			if (y < 60 && (x > 33 || x < 30))
				dirtGrid[x][y] = new Dirt(this, x, y);
			else if ((x <= 33 && x >= 30) && (y < 4))
				dirtGrid[x][y] = new Dirt(this, x, y);
		}
	}
}

// Students:  Add code to this file (if you wish), StudentWorld.h, Actor.h and Actor.cpp
