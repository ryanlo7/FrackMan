#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"

class StudentWorld;
class Actor : public GraphObject 
{
public:
	Actor(int imageID, int x, int y, Direction dir, double s, unsigned int depth, StudentWorld* w);
	virtual ~Actor();
	virtual void doSomething() = 0;
	StudentWorld* getWorld();
	bool getAlive();
	void setAlive(bool b);
private:
	StudentWorld* m_world;
	bool alive;
};

class Dirt : public Actor  
{
public:
	Dirt(StudentWorld* w, int x, int y);
	virtual ~Dirt();
	virtual void doSomething();
};
class Mover : public Actor
{
public:
	Mover(StudentWorld* w, int imageID, int x, int y, Direction dir);
	virtual ~Mover();
	int getHealth();
	void setHealth(int h);

	//virtual void annoy(); // maybe
private:
	int health;
};
class Frackman : public Mover
{
public:
	Frackman(StudentWorld* w, int x, int y);
	virtual ~Frackman() { setVisible(false);  }
	//virtual void annoy(); // maybe
	//int getWater();
	//int getNuggets();
	//int getSonar();
	//int getOil();
	virtual void doSomething();
private:
	int numNuggets;
	int numWater;
	int numSonar;
	int numOil;

};


#endif // ACTOR_H_
