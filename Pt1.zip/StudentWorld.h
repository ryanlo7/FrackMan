#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "GameConstants.h"
#include <string>
#include "Actor.h"

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class StudentWorld : public GameWorld
{
public:
	StudentWorld(std::string assetDir)
		: GameWorld(assetDir)
	{
		frackman = nullptr;
		gridNull();
	}
	void gridNull();
	virtual int init()
	{
		setUpGrid();
		frackman = new Frackman(this, 30, 60);
		return GWSTATUS_CONTINUE_GAME;
	}

	virtual int move()
	{
		  // This code is here merely to allow the game to build, run, and terminate after you hit enter a few times.
		  // Notice that the return value GWSTATUS_PLAYER_DIED will cause our framework to end the current level.
		frackman->doSomething();
		return GWSTATUS_CONTINUE_GAME;
	}

	virtual void cleanUp()
	{
		delete frackman;
		frackman = nullptr;
		for (int r = 0; r < VIEW_HEIGHT; r++)
		{
			for (int c = 0; c < VIEW_WIDTH; c++)
			{
				Dirt* d = dirtGrid[r][c];
				delete d;
				dirtGrid[r][c] = nullptr;
			}
		}
	}
	~StudentWorld();
	
	//bool overlap(int x, int y);
	void setUpGrid();
	void removeDirt(int x, int y);
private:
	Dirt* dirtGrid[VIEW_HEIGHT][VIEW_WIDTH];
	Frackman* frackman;
};

#endif // STUDENTWORLD_H_
