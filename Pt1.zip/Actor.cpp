#include "Actor.h"
#include "StudentWorld.h"

// Students:  Add code to this file (if you wish), Actor.h, StudentWorld.h, and StudentWorld.cpp
Actor::Actor(int imageID, int x, int y, Direction dir, double s, unsigned int depth, StudentWorld* w)
	: GraphObject(imageID, x, y, dir, s, depth)
{ 
	m_world = w;
	alive = true;
}
Actor::~Actor()
{ }
StudentWorld* Actor::getWorld() 
{
	return m_world;
}
bool Actor::getAlive()
{
	return alive;
}
void Actor::setAlive(bool b)
{
	alive = b;
}

Dirt::Dirt(StudentWorld* w, int x, int y) :
	Actor(IID_DIRT, x, y, right, 0.25, 3, w)
{
	setVisible(true);
}
Dirt::~Dirt()
{
	setVisible(false);
}
void Dirt::doSomething() { }

Mover::Mover(StudentWorld* w, int imageID, int x, int y, Direction dir) :
	Actor(imageID, x, y, dir, 1, 0, w)
{ }
Mover::~Mover()
{

}
int Mover::getHealth()
{
	return health;
}
void Mover::setHealth(int h)
{
	health = h;
}


Frackman::Frackman(StudentWorld* w, int x = 30, int y = 60) :
	Mover(w, IID_PLAYER, x, y, right)
{
	setHealth(10);
	numWater = 5;
	numNuggets = 0;
	numSonar = 1;
	setVisible(true);
}
void Frackman::doSomething()
{
	if (getAlive() == false)
		return;
	//Remove Dirt
	getWorld()->removeDirt(getX(), getY() );

	int ch;
	if (getWorld()->getKey(ch) == true)
	{
		switch (ch)
		{
			case KEY_PRESS_LEFT:
				if (getDirection() != left)
					{
						setDirection(left);
						break;
					}
				else if (getX() - 1 >= 0)
					moveTo(getX() - 1, getY());
				else
					moveTo(getX(), getY()); 
				break;
			case KEY_PRESS_RIGHT:
				if (getDirection() != right)
					{
						setDirection(right);
						break;
					}
				else if (getX() + SPRITE_WIDTH < VIEW_WIDTH)
					moveTo(getX() + 1, getY());
				else
					moveTo(getX(), getY());
				break;
			case KEY_PRESS_UP:
				if (getDirection() != up)
					{
						setDirection(up);
						break;
					}
				else if (getY() + SPRITE_HEIGHT < VIEW_HEIGHT)
					moveTo(getX(), getY() + 1);
				else
					moveTo(getX(), getY());
				break;
			case KEY_PRESS_DOWN:
				if (getDirection() != down)
					{
						setDirection(down);
						break;
					}
				else if (getY() - 1 >= 0)
					moveTo(getX(), getY() - 1);
				else
					moveTo(getX(), getY());
				break;
				//insert cases here for squirts, etc:

				//
			default:
				break;
		}
	}
}